package application;

import javafx.beans.property.SimpleStringProperty;

public class Account {
	private String appName;
	private String userName;
	private String appPass;
	public String getAppName() {
		return appName;
	}
	 public Account(String appname, String username ,String pass){
		 setAppName(appname);
		 setUserName(username);
		 setAppPass(pass);
	 }
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getAppPass() {
		return appPass;
	}
	public void setAppPass(String appPass) {
		this.appPass = appPass;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
}
