package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AddAppController extends Main {
	final String fxml = "GeneratePassMenu.fxml";

	@FXML
	private TextField username;
	@FXML
	private TextField pass;
	@FXML
	private TextField repeatedPass;
	@FXML
	private TextField email;
	@FXML
	private TextField duration;
	@FXML
	private TextField appName;
	

	@FXML
	//provide logic behind deleting data and updating the database
	//it returns to main menu after deleting the data
	public void click_submit(ActionEvent event) throws IOException {
		changeScene(event,"MainMenu.fxml");
	}
	@FXML
	//it returns back app info menu
	public void click_cancel(ActionEvent event) throws IOException {
		changeScene(event,"MainMenu.fxml");
	}
	@FXML
	//it returns back app info menu
	public void click_generatePass(ActionEvent event) throws IOException {
		changeScene(event,"GeneratePassMenu.fxml");
	}
	
}