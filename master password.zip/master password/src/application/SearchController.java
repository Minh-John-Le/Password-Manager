package application;

import javafx.fxml.FXML;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class SearchController extends Main{

	final String text = "The password is copied.";
	@FXML
	private Label user;
	@FXML
	private TextField AppName;
	@FXML
	private TextField Username;




	@FXML public void clickCopy(ActionEvent event) throws IOException {
		// copy
		alretMessege(text);
		changeScene(event,"MainMenu.fxml");
	}
	@FXML public void clickMain(ActionEvent event) throws IOException {
		// back to main menu
		changeScene(event,"MainMenu.fxml");
	}
	@FXML public void clickLogout(ActionEvent event) throws IOException {
		//ask for confirmation and sign out
		//update database
		if(alretConfirmation(text)) {
		changeScene(event,"LoginMenu.fxml");
		}
	}
	@FXML public void clickEdit(ActionEvent event) throws IOException {
		//update the table
		changeScene(event,"AppInfoMenu.fxml");
	}
	@FXML public void clickSearch(ActionEvent event) throws IOException {
		//update the table
		
	}

}
