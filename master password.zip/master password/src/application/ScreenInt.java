package application;

import java.lang.ModuleLayer.Controller;

public interface ScreenInt {
	public void setScreenParent(ScreenController controller);

}
