package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class DeleteAppInfoController extends Main{
	final String text = "Do you want to delete this record permanently?";
	@FXML
	private Label appName;
	@FXML
	private Label email;
	@FXML
	private Label username;
	@FXML
	private Label pass;
	@FXML
	private Label creationDate;
	@FXML
	private Label expirationDate;
	@FXML
	private Label day;
	@FXML
	private Button Cancel;
	@FXML
	private Button Delete;
	
	@FXML 
	//initializer fill out the menu with the app information
	//here is a sample showing the UI works
	//The data comes from The database,it should be connected to database
	public void initialize() {
		appName.setText("Google");
		email.setText("john.smith@Gmail.com");
		username.setText("john_Smith78");
		pass.setText("yht34QEf");
		creationDate.setText("03/01/2022");
		expirationDate.setText("09/01/2022");
		day.setText("180");
		}
	@FXML
	//provide logic behind deleting data and updating the database
	//it returns to main menu after deleting the data
	public void clickDelete(ActionEvent event) throws IOException {
		//check if user want to delet the record if yes go back to menu
		if(alretConfirmation(text))
		changeScene(event,"MainMenu.fxml");

	}
	@FXML
	//it returns back app info menu
	public void clickCancel(ActionEvent event) throws IOException {
		
	}



}
