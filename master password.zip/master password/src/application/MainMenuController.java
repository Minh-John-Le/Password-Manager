package application;
	
import java.beans.EventHandler;
import java.io.IOException;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


public class MainMenuController extends Main {
	final String text = "The password is copied.?";
	final String messege = "The Record is Copied?";
	SearchController newSearch;
	ScreenController myController;
	ExpiredPassController newController; 
	@FXML
	private Label user;

	@FXML public void clickEdit(ActionEvent event){
		try {
			changeScene(event,"AppInfoMenu.fxml");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	@FXML public void clickCopy(ActionEvent event){
		try {
			alretMessege(text);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	@FXML public void clickSetting(ActionEvent event){
		try {
			changeScene(event,"SettingMenu.fxml");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	@FXML public void clickLogout(ActionEvent event){
		try {
			if(alretConfirmation(text))
				changeScene(event,"LoginMenu.fxml");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	@FXML public void clickSearch(ActionEvent event){
		try {
			changeScene(event,"SearchMenu.fxml");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	@FXML public void clickExpired(ActionEvent event){
		try {
			
			changeScene(event,"ExpiredPassMenu.fxml");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	@FXML public void clickAdd(ActionEvent event){
		try {
			
			changeScene(event,"AddAppMenu.fxml");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	@FXML public void onCloseRequest(ActionEvent event){
		try {
			
			changeScene(event,"LogoutMenu.fxml");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	private void onClickExit(ActionEvent event) throws IOException{
		if(alretConfirmation(text))
			Platform.exit();
	}
	//this function set the user name that successfully logs in 
	//and sends it to main menu. so the main menu would be able to 
	//show account info associated with this user name

	@FXML private TableView<Account> table;
	@FXML private TableColumn<Account ,String> appName;
	@FXML private TableColumn<Account ,String> userName;
	@FXML private TableColumn<Account , String> appPass;
	public ObservableList<Account> list = FXCollections.observableArrayList(
			new Account("google","John87","1234"),
			new Account("apple","John_yd4","asdf")
	);
	@FXML
	public void initialize() {
		
		appName.setCellValueFactory(new PropertyValueFactory<Account ,String> ("appName"));
		userName.setCellValueFactory(new PropertyValueFactory<Account ,String> ("userName"));
		appPass.setCellValueFactory(new PropertyValueFactory<Account ,String> ("appPass"));
		table.setItems(list);
		table.getSelectionModel().selectFirst();
	}
	
	public void setScreenParent(ScreenController screenParent) {
		myController = screenParent;
	}
}