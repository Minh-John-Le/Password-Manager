package application;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SignupController extends Main{
	final String fxml_1= "LoginMenu.fxml";
	@FXML
	private TextField username;
	@FXML
	private TextField pass;
	@FXML
	private TextField repeatedPass;
	@FXML
	private TextField quest;
	@FXML
	private TextField ans;
	ScreenController myController;
	@FXML
	//it returns back app info menu
	public void click_submit(ActionEvent event) throws IOException {
		//logic for saving new user info in database
		
		
		changeScene(event,fxml_1);
	}
	@FXML
	//it returns back app info menu
	public void click_cancel(ActionEvent event) throws IOException {
		changeScene(event,fxml_1);
	}
	public void click_generatePass(ActionEvent event) throws IOException {
		changeScene(event,"GeneratePassMenu.fxml");
	}

}