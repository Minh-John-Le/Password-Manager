package application;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class FXMLLoaderHandler {
	//
	public void loadStage(String str) throws IOException{
		FXMLLoader Loader = new FXMLLoader((getClass().getResource(str)));
		Parent root = Loader.load();
		//Image icone = new Image("file:obdc.png");
		//primaryStage.getIcons().add(icone);
		Stage primarystage = new Stage();
		primarystage.setTitle("Password Management System");
		Scene scene = new Scene(root);
		primarystage.setScene(scene);
		((Stage)(scene.getWindow())).centerOnScreen();
		primarystage.setResizable(false);
		primarystage.initModality(Modality.APPLICATION_MODAL);
		primarystage.showAndWait();
	}
	//
	public void loadStage(Parent root) throws IOException{
		Stage primarystage = new Stage();
		primarystage.setTitle("Password Management System");
		Scene scene = new Scene(root);
		primarystage.setScene(scene);
		((Stage)(scene.getWindow())).centerOnScreen();
		primarystage.setResizable(false);
		primarystage.initModality(Modality.APPLICATION_MODAL);
		primarystage.showAndWait();
		
	}
/**	public void loadStage(String str,String str2) throws IOException{
		FXMLLoader Loader = new FXMLLoader((getClass().getResource(str)));
		Parent root = Loader.load();
		Stage primarystage = new Stage();
		primarystage.setOnCloseRequest(evt -> {
	        // allow user to decide between yes and no
	        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, str2, ButtonType.YES, ButtonType.NO);
	        // clicking X also means no
	        ButtonType result = alert.showAndWait().orElse(ButtonType.NO);
	        if (ButtonType.NO.equals(result)) {
	            // consume event i.e. ignore close request 
	            evt.consume();
	        }
	    });
		primarystage.setTitle("Password Management System");
		Scene scene = new Scene(root);
		primarystage.setScene(scene);
		((Stage)(scene.getWindow())).centerOnScreen();
		primarystage.setResizable(false);
		primarystage.initModality(Modality.APPLICATION_MODAL);
		primarystage.showAndWait();
		
	}**/
	public void closeMenu(Button button) {
		 Stage stage = (Stage) button.getScene().getWindow();
		 stage.close();
	}

}
