package application;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.stage.Stage;
public class ScreenFramework{
	//address of login fxml
	public static String fxml = "LoginMenu.fxml";
	public static String screenId = "LoginMenu";
	public static String fxml_1 = "MainMenu.fxml";
	public static String screenId_1 = "MainMenu";
	//this is the starting point of the program
	@Override
	public void start(Stage primaryStage) {
		try {
        ScreenController myController = new ScreenController();
        
        myController.loadScreen(screenId_1, fxml_1);
        System.out.println(myController.menu.size());
        System.out.println("2 screen");
        myController.loadScreen(screenId, fxml);
        System.out.println(myController.menu.size());
        myController.setScreen(fxml_1);
        Group root = new Group();
        root.getChildren().addAll(myController);
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	public void setScreenParent(ScreenController screenParent){
		myController = screenParent;
	}

}
