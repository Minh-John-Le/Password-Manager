package application;

import java.util.HashMap;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;

public class ScreenController extends StackPane{
	public HashMap<String,Scene> menu = new HashMap<>();

	public ScreenController() {
		super();
	}
	
	public void addScreen(String name,Scene screen){
		menu.put(name, screen);
	}	
	
	public Boolean loadScreen(String name,String fxml){
		try{
			FXMLLoader loader =  new FXMLLoader(getClass().getResource(fxml));
			Parent root = (Parent)loader.load();
			ScreenInt newScreenInt = ((ScreenInt)loader.getController());
			newScreenInt.setScreenParent(this);
			Scene scene = new Scene(root);
			addScreen(name,scene);
			return true;
		}catch(Exception e){
			return false;
		}
	}
	
	public Boolean unloadScreen(String name){
		if(menu.remove(name)==null) {
			 System.out.println("menu didn't exist");
			return false;
		}
		return true;
	}
	
	public Scene getScreen(String name){
		return menu.get(name);
		
	}
	
	public Boolean setScreen(final String name){
		if(menu.get(name)!= null) {
			System.out.println("screen");
			if(!getChildren().isEmpty()) {
				System.out.println("screen not empty");
					getChildren().remove(0); 
					getChildren().add(0, menu.get(name));
			}else {
			getChildren().add(0, menu.get(name));
			}
			return true;
		}
		System.out.println("no screen");
		return false;
	}
}
