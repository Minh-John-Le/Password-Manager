package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class ExpiredPassController extends Main{
	final String text = "Do You Want To Logout?";
	@FXML
	private Label user;

	@FXML public void click_Edit(ActionEvent event){
		try {
			
			changeScene(event,"AppInfoMenu.fxml");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	@FXML public void click_Logout(ActionEvent event){
		try {
			if(alretConfirmation(text))
			closeStage(event,text);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	@FXML public void click_Main(ActionEvent event){
		try {
			
			changeScene(event,"MainMenu.fxml");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	@FXML public void click_Setting(ActionEvent event){
		try {
			
			changeScene(event,"SettingMenu.fxml");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
