Please modify click_changeDuration function in your AppInfoController.java  with following code:


@FXML public void click_changeDuration(ActionEvent event) throws IOException {
		//open change Duration menu
		changeScene(event,"ChangeDurationMenu.fxml");
	}