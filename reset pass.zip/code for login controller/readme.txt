few lines have changed in login controller:
line 14 : address of new fxml file
line 76 : the click_forgetPass function is changed to new code 