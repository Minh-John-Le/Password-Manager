These are all controllers needed for reset Login's password.
add these new controllers to your src and check the folder's readme.txt for few changes in Login Controller